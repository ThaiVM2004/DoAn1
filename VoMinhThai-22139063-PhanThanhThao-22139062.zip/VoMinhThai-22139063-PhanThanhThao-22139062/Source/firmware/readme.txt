Cách chạy các file:
- Sau khi tải về ta được các file .ino tiến hành mở lên và nạp code cho các vi điều khiển, khi nạp cần lưu ý:
+ Với esp32 - cam: đổi cấu hình wifi lại cho phù hợp với wifi của mình
+ Trong file .ino của esp32 có đường dẫn đến URL của Apps Script vui lòng đổi lại thành của mình bằng cách truy cập vào Apps Script -> chọn Deploy -> Chon Manager Deployment -> Tìm đến URL và coppy dán vào
+ Nhớ public bạn nhé
+ Code trên stm32 nạp bình thường