Các lưu ý khi chạy file:
+ Nếu muốn phát triển thêm thì có thể truy cập vào file UI.py
+ gõ lệnh này vào terminal nếu muốn build file .exe pyinstaller --onefile --add-data "hcmute.png;." UI.py
