# Sử dụng logo: "0482c6d2-44d1-4855-8f91-7a57518e5184.png"
# Đổi tên file logo thành: "logo.png" và đặt cùng thư mục với file .py

import sys
import os
import serial
import serial.tools.list_ports
import webbrowser
from PyQt5.QtWidgets import (QApplication, QWidget, QPushButton, QLabel, QTextEdit,
                             QVBoxLayout, QHBoxLayout, QComboBox, QLineEdit, QFrame)
from PyQt5.QtCore import QTimer, QSize, Qt
from PyQt5.QtGui import QPixmap


class SerialMonitor(QWidget):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("GIAO DIỆN QUẢN TRỊ VIÊN")
        self.setFixedSize(QSize(800, 600))

        self.serial = serial.Serial()
        self.timer = QTimer()
        self.timer.timeout.connect(self.read_serial)

        # === HEADER ===
        header_layout = QVBoxLayout()

        logo = QLabel()
        def resource_path(relative_path):
            """Trả về đường dẫn thực tế (hỗ trợ cả khi chạy script và khi đã build bằng PyInstaller)"""
            if getattr(sys, 'frozen', False):  # Nếu đang chạy trong file .exe
                base_path = sys._MEIPASS
            else:
                base_path = os.path.abspath(".")

            return os.path.join(base_path, relative_path)
        
        logo_path = resource_path("hcmute.png")
        logo.setPixmap(QPixmap(logo_path).scaledToHeight(120, Qt.SmoothTransformation))
        logo.setAlignment(Qt.AlignCenter)

        title = QLabel("<h2>HỆ THỐNG CHẤM CÔNG TỰ ĐỘNG</h2>")
        title.setAlignment(Qt.AlignCenter)

        student_info = QLabel(
            "Võ Minh Thái - 22139063<br>Phan Thanh Thảo - 22139062"
        )
        student_info.setAlignment(Qt.AlignCenter)

        github_link = QLabel("<a href='https://github.com/ThaiVM2004/X-Y-D-NG-H-TH-NG-CH-M-C-NG-T-NG-NG-D-NG-TRONG-QU-N-L-NH-N-S-'>🔗 GitHub</a>")
        github_link.setAlignment(Qt.AlignCenter)
        github_link.setOpenExternalLinks(True)

        header_layout.addWidget(logo)
        header_layout.addWidget(title)
        header_layout.addWidget(student_info)
        header_layout.addWidget(github_link)

        line = QFrame()
        line.setFrameShape(QFrame.HLine)
        line.setFrameShadow(QFrame.Sunken)
        header_layout.addWidget(line)

        # === NỘI DUNG ===
        self.text_display = QTextEdit()
        self.text_display.setReadOnly(True)

        self.input_line = QLineEdit()
        self.input_line.setPlaceholderText("Nhập dữ liệu gửi đến serial")

        self.port_box = QComboBox()
        self.refresh_ports()

        self.refresh_btn = QPushButton("⟳")
        self.refresh_btn.setToolTip("Tải lại cổng COM")
        self.refresh_btn.clicked.connect(self.refresh_ports)
        self.refresh_btn.setFixedWidth(30)

        self.baudrate_box = QComboBox()
        self.baudrate_box.addItems(["9600", "19200", "38400", "57600", "115200"])
        self.baudrate_box.setCurrentText("9600")

        self.btn_connect = QPushButton("Kết nối")
        self.btn_connect.clicked.connect(self.connect_serial)

        self.btn_disconnect = QPushButton("Ngắt kết nối")
        self.btn_disconnect.clicked.connect(self.disconnect_serial)

        self.btn_send = QPushButton("Gửi")
        self.btn_send.clicked.connect(self.send_data)

        self.btn_open_sheet = QPushButton("Mở Google Sheet")
        self.btn_open_sheet.clicked.connect(lambda: webbrowser.open("https://docs.google.com/spreadsheets/d/1mrLJTpO7Z-Uq4t1LPaHEph116n_3Zp6sXbt91vUptXc/edit?usp=sharing"))

        port_layout = QHBoxLayout()
        port_layout.addWidget(QLabel("Cổng COM:"))
        port_layout.addWidget(self.port_box)
        port_layout.addWidget(self.refresh_btn)
        port_layout.addWidget(QLabel("Baudrate:"))
        port_layout.addWidget(self.baudrate_box)

        control_layout = QHBoxLayout()
        control_layout.addWidget(self.btn_connect)
        control_layout.addWidget(self.btn_disconnect)
        control_layout.addWidget(self.btn_open_sheet)

        input_layout = QHBoxLayout()
        input_layout.addWidget(self.input_line)
        input_layout.addWidget(self.btn_send)

        main_layout = QVBoxLayout()
        main_layout.addLayout(header_layout)
        main_layout.addLayout(port_layout)
        main_layout.addLayout(control_layout)
        main_layout.addWidget(QLabel("Dữ liệu từ Serial:"))
        main_layout.addWidget(self.text_display)
        main_layout.addLayout(input_layout)

        self.setLayout(main_layout)
        self.set_bright_theme()

    def set_bright_theme(self):
        self.setStyleSheet("""
            QWidget {
                background-color: #f4f4f4;
                color: #111;
                font-family: 'Segoe UI', sans-serif;
                font-size: 12pt;
            }
            QTextEdit, QLineEdit, QComboBox {
                background-color: #ffffff;
                color: #000;
                border: 1px solid #ccc;
                border-radius: 4px;
            }
            QPushButton {
                background-color: #e0e0e0;
                color: #000;
                border: 1px solid #aaa;
                border-radius: 4px;
                padding: 6px;
            }
            QPushButton:hover {
                background-color: #d6d6d6;
            }
            QLabel {
                color: #111;
            }
            a {
                color: #0066cc;
                text-decoration: none;
            }
            a:hover {
                text-decoration: underline;
            }
        """)

    def refresh_ports(self):
        ports = serial.tools.list_ports.comports()
        self.port_box.clear()
        for port in ports:
            self.port_box.addItem(port.device)

        if len(ports) == 1:
            self.port_box.setCurrentIndex(0)
            self.text_display.append(f"[INFO] Tự động chọn cổng: {ports[0].device}")
        elif len(ports) == 0:
            self.text_display.append("[INFO] Không tìm thấy cổng COM nào.")
        else:
            self.text_display.append("[INFO] Đã tải lại danh sách cổng COM.")

    def connect_serial(self):
        port = self.port_box.currentText()
        baudrate = int(self.baudrate_box.currentText())
        try:
            self.serial.port = port
            self.serial.baudrate = baudrate
            self.serial.open()
            self.timer.start(100)
            self.text_display.append(f"[INFO] Đã kết nối với {port} @ {baudrate} baud.")
        except serial.SerialException as e:
            self.text_display.append(f"[LỖI] Không thể mở cổng {port}: {e}")

    def disconnect_serial(self):
        if self.serial.is_open:
            self.timer.stop()
            self.serial.close()
            self.text_display.append("[INFO] Ngắt kết nối serial.")

    def read_serial(self):
        if self.serial.in_waiting:
            try:
                data = self.serial.readline().decode("utf-8", errors="ignore").strip()
                self.text_display.append(f">> {data}")
                self.text_display.moveCursor(self.text_display.textCursor().End)
            except Exception as e:
                self.text_display.append(f"[LỖI đọc]: {e}")

    def send_data(self):
        if self.serial.is_open:
            msg = self.input_line.text()
            self.serial.write(msg.encode())
            self.text_display.append(f"<< {msg}")
            self.text_display.moveCursor(self.text_display.textCursor().End)
            self.input_line.clear()


if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = SerialMonitor()
    window.show()
    sys.exit(app.exec_())
