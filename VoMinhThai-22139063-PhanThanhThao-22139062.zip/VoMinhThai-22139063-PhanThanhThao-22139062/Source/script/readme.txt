Các lưu ý: 
- Để esp32-cam có thể phản hồi bạn vào Apps Script và dán vào đoạn code trong main.txt nhé